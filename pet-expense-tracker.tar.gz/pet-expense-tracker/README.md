# Pet Expense Tracker - MVP

A simple, elegant web application for tracking pet-related expenses. Built with vanilla HTML, CSS, and JavaScript, with data persistence using browser localStorage.

## Project Overview

**Pet Expense Tracker** is a Minimum Viable Product (MVP) designed to help pet owners keep track of their spending on pet care. This is **Stage 1** of a two-stage development approach:

- **Stage 1 (Current)**: Free, simple, and functional MVP to validate the idea and build an audience
- **Stage 2 (Future)**: Premium version with advanced features, user authentication, and subscription model

## Features

### Core Functionality

1. **Dashboard**
   - Total spending display for the current month
   - Spending breakdown by category (visual cards)
   - Recent expenses list (last 5 entries)

2. **Add Expense**
   - Simple form to log new expenses
   - Category selector with 8 predefined categories
   - Date picker (defaults to today)
   - Optional notes field
   - Real-time data persistence

3. **History**
   - Complete log of all expenses
   - Category filter
   - Delete functionality
   - Chronological ordering (newest first)

## Design

- **Dark Theme**: Professional dark UI with #161616 background
- **Accent Color**: Bright lime green (#acf92c) for highlights and calls-to-action
- **Typography**: Montserrat font family for modern, clean appearance
- **Responsive**: Fully responsive design for desktop, tablet, and mobile devices
- **Apple-style**: Clean, minimalist design with subtle shadows and smooth transitions

## Technical Stack

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with flexbox and grid
- **JavaScript (Vanilla)**: No frameworks or dependencies
- **localStorage**: Client-side data persistence

## Project Structure

```
pet-expense-tracker/
├── index.html          # Main HTML file
├── css/
│   └── styles.css      # All styling
├── js/
│   └── app.js          # Core application logic
├── assets/             # Images and icons (for future use)
└── README.md           # This file
```

## Getting Started

### Local Development

1. Clone or download the project
2. Open `index.html` in a modern web browser
3. Start adding expenses!

### No Installation Required

This is a static web application with no build process or dependencies. Simply open the HTML file and it works immediately.

## Data Storage

All expenses are stored in the browser's `localStorage`. This means:

- **Pros**: No server needed, instant data persistence, privacy-focused
- **Cons**: Data is stored locally on the device, not synced across devices

For the Stage 2 premium version, we'll implement cloud sync with a backend database.

## Categories

The app includes 8 predefined expense categories:

- 🍖 Food
- 🎾 Toys
- 🍪 Treats
- 🏥 Vet Bills
- 💊 Medication
- ✂️ Grooming
- 🦴 Accessories
- 📌 Other

## Browser Compatibility

Works on all modern browsers that support:
- ES6 JavaScript
- CSS Grid and Flexbox
- localStorage API

Tested on:
- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Future Enhancements (Stage 2)

- User authentication (login/signup)
- Cloud data sync
- Advanced analytics and reports
- Multi-pet support
- Budget alerts and notifications
- Export functionality (CSV, PDF)
- Dark/Light theme toggle
- Premium subscription features

## Monetization Strategy

### Stage 1 (Current MVP)
- Free with optional Google AdSense integration
- Affiliate links for pet products

### Stage 2 (Premium Version)
- $29/month subscription
- Premium features (advanced reports, multi-pet, cloud sync)
- Ad-free experience

## Deployment

This app can be deployed to any static hosting platform:

- **Netlify** (recommended)
- **Vercel**
- **GitHub Pages**
- **Cloudflare Pages**
- **Firebase Hosting**

Simply push the files to a Git repository and connect it to your hosting platform for automatic deployment.

## Development Notes

### Code Structure

The application is built around a single `ExpenseTracker` class that handles:
- Data management (CRUD operations)
- Event handling
- DOM rendering
- localStorage persistence

### Key Methods

- `addExpense()`: Add a new expense
- `deleteExpense()`: Remove an expense
- `getTotalSpending()`: Calculate monthly total
- `getSpendingByCategory()`: Get category breakdown
- `render()`: Update all UI elements

### Security

- HTML escaping to prevent XSS attacks
- Input validation on forms
- No sensitive data stored

## License

This project is created for educational and commercial use.

## Support

For questions or issues, please refer to the main project documentation or contact the development team.

---

**Version**: 1.0.0 (MVP)  
**Last Updated**: October 2025  
**Status**: Ready for deployment

